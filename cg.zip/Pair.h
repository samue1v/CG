#ifndef PAIR_H
#define PAIR_H

template <typename T> struct Pair {
  T left;
  T right;
};

#endif