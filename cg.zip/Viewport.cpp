#include "Scene.h"
#include "Viewport.h"
#include "Coordinate.h"
#include "Vector.h"
#include "Polygons.h"
#include "Pair.h"
#include "Coordinate.h"
#include <stdio.h>


Coordinate canvasToViewport(float x, float y){return Coordinate{0,0,0};};
