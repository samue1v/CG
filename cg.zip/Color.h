#ifndef COLOR_H
#define COLOR_H

struct Color {
  unsigned char red;
  unsigned char green;
  unsigned char blue;
  Color();
  Color(int red, int green, int blue);
};
#endif
