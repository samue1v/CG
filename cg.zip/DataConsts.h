#ifndef DATACONSTS_H
#define DATACONSTS_H

const int INF = 10e8;
const unsigned char COLOR_MAX = 255;
const unsigned char COLOR_MIN = 0;


#endif
